// Jessy Pawlowski
// Homework02_Program01
// CIS 183
// RGB Color Picker

package com.example.homework02_program1;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // save button
        Button btn_v_01 = findViewById(R.id.btn_v_01);
        // list
        ListView listView = findViewById(R.id.lv_v_01);
        // text view
        TextView tvColor = findViewById(R.id.tv_v_01);

        // connecting seekbars to the IDs in Main
        SeekBar sbR = findViewById(R.id.sb_v_01);
        SeekBar sbG = findViewById(R.id.sb_v_02);
        SeekBar sbB = findViewById(R.id.sb_v_03);

        // set max scale values
        sbR.setMax(255);
        sbG.setMax(255);
        sbB.setMax(255);

        View mainLayout = findViewById(R.id.mainLayout);

        SeekBar.OnSeekBarChangeListener colorListener = new SeekBar.OnSeekBarChangeListener()
        {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
            {
                int red = sbR.getProgress();
                int green = sbG.getProgress();
                int blue = sbB.getProgress();

                int color = Color.rgb(red, green, blue);
                mainLayout.setBackgroundColor(color);

                String hex = String.format("#%02X%02X%02X", red, green, blue);
                tvColor.setText(hex);

                // calling our function that adjusts text color if the background is too dim or bright
                adjustText(tvColor, Color.red(color), Color.green(color), Color.blue(color));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar)
            {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar)
            {

            }

        };

        sbR.setOnSeekBarChangeListener(colorListener);
        sbG.setOnSeekBarChangeListener(colorListener);
        sbB.setOnSeekBarChangeListener(colorListener);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.mainLayout), (v, insets) ->
        {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Making the list
        ArrayList<String> savedColors = new ArrayList<>();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, savedColors);
        listView.setAdapter(adapter);

        // making the save button save to list
        btn_v_01.setOnClickListener(v ->
        {
            // find the current values for r, g, and b
            int red = sbR.getProgress();
            int green = sbG.getProgress();
            int blue = sbB.getProgress();

            // then to convert the color to a hex code
            String hex = String.format(java.util.Locale.US, "#%02X%02X%02X", red, green, blue);

            tvColor.setText(hex);

            // calling our text color function
            adjustText(tvColor, red, green, blue);

            // saving the solor here
            savedColors.add(hex);
            adapter.notifyDataSetChanged();

            // reset the slider and background now
            sbR.setProgress(0);
            sbG.setProgress(0);
            sbB.setProgress(0);
            mainLayout.setBackgroundColor(Color.WHITE);
            tvColor.setText("#FFFFFF");

        });

        // pick a saved color from the list
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                // get selection
                String hex = savedColors.get(position);

                // convert the hex to an android color
                int color = Color.parseColor(hex);

                // apply the chosen color
                sbR.setProgress(Color.red(color));
                sbG.setProgress(Color.green(color));
                sbB.setProgress(Color.blue(color));
            }
        });

    }

    private void adjustText(TextView tvColor, int red, int green, int blue)
    {
        // get the brightness of the chosen color
        double brightness = (0.299 * red + 0.587 * green +0.114 * blue);

        // change the text color based on brightness
        if (brightness < 128)
        {
            tvColor.setTextColor(Color.WHITE);
        }
        else
        {
            tvColor.setTextColor(Color.BLACK);

        }
    }
}